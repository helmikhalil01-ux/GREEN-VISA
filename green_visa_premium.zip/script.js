// Simple slider control for gallery
(function(){
  const slides = document.querySelector('.slides');
  const slideCount = document.querySelectorAll('.slide').length;
  let idx = 0;
  const nextBtn = document.getElementById('next');
  const prevBtn = document.getElementById('prev');
  function go(i){ idx = (i + slideCount) % slideCount; slides.style.transform = 'translateX(' + (-idx*100) + '%)'; }
  function next(){ go(idx+1); }
  function prev(){ go(idx-1); }
  if(nextBtn) nextBtn.addEventListener('click', ()=>{ next(); reset(); });
  if(prevBtn) prevBtn.addEventListener('click', ()=>{ prev(); reset(); });
  let timer = setInterval(next, 4500);
  function reset(){ clearInterval(timer); timer = setInterval(next, 4500); }
})();
